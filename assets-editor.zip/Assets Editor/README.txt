Sources available in:
https://github.com/Arch-Mina/Assets-Editor

Credits to Arch-Mina.

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenTibiaCommons.Domain
{
    public class OtTrashHolder : OtItem
    {
        public OtTrashHolder(OtItemType type) : base(type) { }
    }
}

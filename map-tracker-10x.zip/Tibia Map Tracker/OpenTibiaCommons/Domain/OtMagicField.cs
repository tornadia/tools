using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenTibiaCommons.Domain
{
    public class OtMagicField : OtItem
    {
        public OtMagicField(OtItemType type) : base(type) { }
    }
}

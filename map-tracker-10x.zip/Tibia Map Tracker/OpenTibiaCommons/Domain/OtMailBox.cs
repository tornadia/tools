﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenTibiaCommons.Domain
{
    public class OtMailBox : OtItem
    {
        public OtMailBox(OtItemType type) : base(type) { }
    }
}

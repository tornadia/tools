using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpTibiaProxy.Domain
{
    public enum Skills
    {
        FIRST = 0,
        FIST = FIRST,
        CLUB,
        SWORD,
        AXE,
        DIST,
        SHIELD,
        FISH,
        _MAGLEVEL,
        _LEVEL,
        _EXPERIENCE,
        LAST = FISH,
        _LAST = _EXPERIENCE
    };

}

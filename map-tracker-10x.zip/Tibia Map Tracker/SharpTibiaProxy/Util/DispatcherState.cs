namespace SharpTibiaProxy.Util
{
    public enum DispatcherState
    {
        Running,
        Closing,
        Terminated
    };
}


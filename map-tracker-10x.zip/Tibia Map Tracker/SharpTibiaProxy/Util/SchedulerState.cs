using System;

namespace SharpTibiaProxy.Util
{
    public enum SchedulerState
    {
        Running,
        Closing,
        Terminated
    };
}

